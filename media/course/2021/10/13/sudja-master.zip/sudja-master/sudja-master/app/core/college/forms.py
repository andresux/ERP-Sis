from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.forms import *
from .models import *


class MatterForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['autofocus'] = True

    class Meta:
        model = Matter
        fields = '__all__'
        widgets = {
            'name': TextInput(attrs={'placeholder': 'Ingrese un nombre'})
        }
        exclude = ['user_updated', 'user_creation', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)

    def save(self, commit=True):
        data = {}
        try:
            if self.is_valid():
                super().save()
            else:
                data['error'] = self.errors
        except:
            pass
        return data


class ProfessionForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['autofocus'] = True

    class Meta:
        model = Profession
        fields = '__all__'
        widgets = {
            'name': TextInput(attrs={'placeholder': 'Ingrese un nombre'})
        }
        exclude = ['user_updated', 'user_creation', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)

    def save(self, commit=True):
        data = {}
        try:
            if self.is_valid():
                super().save()
            else:
                data['error'] = self.errors
        except:
            pass
        return data


class PeriodForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['autofocus'] = True

    class Meta:
        model = Period
        fields = '__all__'
        widgets = {
            'name': TextInput(attrs={'placeholder': 'Ingrese un nombre'})
        }
        exclude = ['user_updated', 'user_creation', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)

    def save(self, commit=True):
        data = {}
        try:
            if self.is_valid():
                super().save()
            else:
                data['error'] = self.errors
        except:
            pass
        return data


class PersonForm(UserCreationForm):
    first_name = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese sus nombres'}), label='Nombres')
    last_name = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese sus apellidos'}), label='Apellidos')
    dni = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su número de cedula'}), label='Número de cedula',
                    max_length=13)
    email = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su email'}), label='Email')
    gender = ChoiceField(choices=gender, widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
                         label='Genero')
    address = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su dirección'}), label='Dirección')
    mobile = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su teléfono celular'}), label='Teléfono celular',
                       max_length=10)
    conventional = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su teléfono convencional'}),
                             label='Teléfono convencional', max_length=7)
    birthdate = DateField(input_formats=['%Y-%m-%d'], widget=TextInput(attrs={
        'value': datetime.now().strftime('%Y-%m-%d'),
        'id': 'birthdate',
        'class': 'form-control datetimepicker-input',
        'data-toggle': 'datetimepicker',
        'data-target': '#birthdate',
    }), label='Fecha de nacimiento')
    # type = ChoiceField(choices=type_pers,
    #                    widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}), label='Tipo')
    profession = ModelChoiceField(queryset=Profession.objects.filter(),
                                  widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
                                  label='Profesión', required=True)
    cviate = FileField(label='C.Vitae')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['autofocus'] = True
        super(UserCreationForm, self).__init__(*args, **kwargs)
        del self.fields['password1']
        del self.fields['password2']
        del self.fields['username']

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'dni', 'email', 'image')
        exclude = ['user_creation', 'user_updated']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class PersonChangeForm(UserChangeForm):
    first_name = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese sus nombres'}), label='Nombres')
    last_name = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese sus apellidos'}), label='Apellidos')
    dni = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su número de cedula'}), label='Número de cedula',
                    max_length=13)
    email = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su email'}), label='Email')
    gender = ChoiceField(choices=gender, widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
                         label='Genero')
    address = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su dirección'}), label='Dirección')
    mobile = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su teléfono celular'}), label='Teléfono celular',
                       max_length=10)
    conventional = CharField(widget=TextInput(attrs={'placeholder': 'Ingrese su teléfono convencional'}),
                             label='Teléfono convencional', max_length=7)
    birthdate = DateField(input_formats=['%Y-%m-%d'], widget=TextInput(attrs={
        'value': datetime.now().strftime('%Y-%m-%d'),
        'id': 'birthdate',
        'class': 'form-control datetimepicker-input',
        'data-toggle': 'datetimepicker',
        'data-target': '#birthdate',
    }), label='Fecha de nacimiento')
    # type = ChoiceField(choices=type_pers,
    #                    widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}), label='Tipo')
    profession = ModelChoiceField(queryset=Profession.objects.filter(),
                                  widget=Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
                                  label='Profesión', required=True)
    cviate = FileField(label='C.Vitae')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['autofocus'] = True
        super(PersonChangeForm, self).__init__(*args, **kwargs)
        del self.fields['password']
        del self.fields['username']

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'dni', 'email', 'image')
        exclude = ['user_creation', 'user_updated']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class CourseForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['classroom'].widget.attrs['autofocus'] = True

    class Meta:
        model = Course
        fields = '__all__'
        widgets = {
            'classroom': Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
            'period': Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
            'level': Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
        }
        exclude = ['user_updated', 'user_creation', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class TeacherMatterForm(ModelForm):
    def __init__(self, *args, **kwargs):
        edit = kwargs.pop('edit', False)
        super().__init__(*args, **kwargs)
        self.fields['teacher'].widget.attrs['autofocus'] = True
        self.fields['teacher'].queryset = Person.objects.filter(type='docente')
        if edit:
            self.fields['period'].widget.attrs['disabled'] = True
            self.fields['teacher'].widget.attrs['disabled'] = True

    class Meta:
        model = TeacherMatter
        fields = '__all__'
        widgets = {
            'teacher': Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
            'period': Select(attrs={'class': 'form-control select2', 'style': 'width: 100%'}),
        }
        exclude = ['user_updated', 'user_creation', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class MatriculationForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['course'].widget.attrs['autofocus'] = True

    class Meta:
        model = Matriculation
        fields = '__all__'
        widgets = {
            'course': Select(attrs={'class': 'form-control select2', 'style': 'width:100%;'}),
        }
        exclude = ['user_updated', 'user_creation', 'date_joined', 'student', 'state']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class MatrStateForm(forms.Form):
    state_matricul = (
        ('', '-------'),
        ('aprobado', 'Aprobado'),
        ('rechazado', 'Rechazado'),
    )

    state = ChoiceField(choices=state_matricul, widget=Select(
        attrs={
            'class': 'form-control select2',
            'style': 'width: 100%'
        }))


class ClassRoomForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['autofocus'] = True

    class Meta:
        model = ClassRoom
        fields = '__all__'
        widgets = {
            'name': TextInput(attrs={'placeholder': 'Ingrese un nombre'}),
            'description': TextInput(attrs={'placeholder': 'Ingrese una Descripción'}),
            'platform_infrastructure': TextInput(attrs={'placeholder': 'Ingrese una plataforma'}),
            'duration': TextInput(attrs={'placeholder': 'Ingrese las horas que durará el curso'}),
        }
        exclude = ['user_updated', 'user_creation']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)

    def save(self, commit=True):
        data = {}
        try:
            if self.is_valid():
                super().save()
            else:
                data['error'] = self.errors
        except:
            pass
        return data


class CommentsForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['message'].widget.attrs['autofocus'] = True

    class Meta:
        model = Comments
        fields = '__all__'
        widgets = {
            'message': Textarea(attrs={'placeholder': 'Ingrese su queja o comentario', 'rows': 4, 'cols': 4}),
        }
        exclude = ['user_updated', 'user_creation', 'pers', 'date_joined']

    id = IntegerField(widget=HiddenInput(attrs={'id': 'id'}), initial=0)


class NotesForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    class Meta:
        model = Notes
        fields = '__all__'
        exclude = ['date_joined']

    course = ChoiceField(choices=[], widget=Select(
        attrs={
            'class': 'form-control select2',
            'style': 'width: 100%'
        }))

    matters = ChoiceField(choices=[], widget=Select(
        attrs={
            'class': 'form-control select2',
            'style': 'width: 100%'
        }))

    semester = ChoiceField(choices=semester, widget=Select(
        attrs={
            'class': 'form-control select2',
            'style': 'width: 100%'
        }))


class NoteStudentForm(forms.Form):
    def __init__(self, *args, **kwargs):
        student_id = kwargs.pop('student_id', 0)
        super().__init__(*args, **kwargs)
        if student_id > 0:
            self.fields['course'].queryset = Matriculation.objects.filter(student_id=student_id)

    course = ModelChoiceField(queryset=None, widget=Select(
        attrs={
            'class': 'form-control select2',
            'style': 'width: 100%'
        }))
