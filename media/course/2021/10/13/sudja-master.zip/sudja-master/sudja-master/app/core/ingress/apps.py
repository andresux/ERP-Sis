from django.apps import AppConfig


class IngressConfig(AppConfig):
    name = 'core.ingress'
