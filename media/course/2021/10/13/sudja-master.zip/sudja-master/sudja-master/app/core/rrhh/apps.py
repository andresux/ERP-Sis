from django.apps import AppConfig


class RrhhConfig(AppConfig):
    name = 'core.rrhh'
