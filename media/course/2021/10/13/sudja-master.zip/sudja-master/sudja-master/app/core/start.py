from random import randint

from config.wsgi import *
from core.ingress.models import Banks
from core.security.models import *
from core.college.models import *
from core.rrhh.models import *

month = 7
year = 2020

days = 0
if month in [1, 3, 5, 7, 8, 10, 12]:
    days = 31
elif month in [4, 6, 9, 11]:
    days = 30
elif month in [2]:
    days = 29

teachers = Contracts.objects.filter(state=True)

# for i in range(1, 5):
#     a = Assistance()
#     a.day = i
#     a.month = month
#     a.year = 2020
#     a.save()
#     print('Dia:{} Mes:{} Año:{}'.format(i, month, year))
#     for t in teachers:
#         det = AssistanceDet()
#         det.assist_id = a.id
#         det.cont_id = t.id
#         det.state = randint(1, 10) % 2 == 0
#         det.save()

for sem in semester:
    print(sem[1])